﻿using ExcelDna.Integration;

namespace Add_in_test
{
    public static class Class1
    {
        [ExcelFunction(Description = "My first .NET function")]
        public static string SayHello(string name)
        {
            return "Hello " + name;
        }
    }
}
